<footer>
    <article class="container">
        <div>
            <a href="index.php"><img src="img/logo-02.png" alt=""></a>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore dolore debitis ullam cum magnam
                molestias nobis, voluptates temporibus accusantium corrupti recusandae sequi? Facilis qui asperiores
                voluptates molestiae illum earum quo.</p>
        </div>

        <div>
            <h3>links</h3>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="courses.php">Courses</a></li>
                <li><a href="teachers.php">Teachers</a></li>
                <li><a href="intro.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>

        <div>
            <h3>contact us</h3>
            <ul>
                <li><i class="fas fa-home"></i>379 5th Ave New York, NYC 10018</li>
                <li><i class="fas fa-phone"></i>(+1) 96 716 6879</li>
                <li><i class="fas fa-fax"></i>(+1) 96 716 6879</li>
                <li><i class="fas fa-envelope"></i>contact@site.com</li>
                <li><i class="fas fa-clock"></i>Mon-Fri 09:00 - 17:00</li>
            </ul>
        </div>
    </article>
    <article>
        <p>@ 2018 AuThemes.</p>
    </article>
</footer>

<script src="main.js"></script>
</body>

</html>